(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/dashboard/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function Card(param) {
    let { title, actions, children } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white p-4 rounded-lg shadow-sm w-full",
        children: [
            (title || actions) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    title ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-semibold text-black",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/components/Card.tsx",
                        lineNumber: 9,
                        columnNumber: 20
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {}, void 0, false, {
                        fileName: "[project]/src/app/dashboard/components/Card.tsx",
                        lineNumber: 9,
                        columnNumber: 84
                    }, this),
                    actions ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: actions
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/components/Card.tsx",
                        lineNumber: 10,
                        columnNumber: 22
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/components/Card.tsx",
                lineNumber: 8,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/components/Card.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/components/Card.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/dashboard/ZabbixCharts.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ZabbixCharts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-chartjs-2/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/chart.js/dist/chart.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Chart"].register(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CategoryScale"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LinearScale"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PointElement"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LineElement"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Title"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Tooltip"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Legend"]);
function ZabbixCharts(param) {
    let { host, minutes = 60, mode = 'both' } = param;
    _s();
    const [memData, setMemData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [trafData, setTrafData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [err, setErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [memLoading, setMemLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [trafLoading, setTrafLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Fetch helpers so we can also refresh on demand
    const fetchMemOnce = async ()=>{
        setMemLoading(true);
        try {
            setErr(null);
            const memUrl = "/api/zbx/metrics/memory?".concat(host ? "host=".concat(encodeURIComponent(host), "&") : "", "minutes=").concat(minutes);
            const r = await fetch(memUrl);
            const j = await r.json();
            if (j === null || j === void 0 ? void 0 : j.ok) setMemData(j.mem);
            else setErr(j.error || "Erro ao obter memória");
        } catch (e) {
            setErr(String(e));
        } finally{
            setMemLoading(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ZabbixCharts.useEffect": ()=>{
            let alive = true;
            fetchMemOnce();
            const id = setInterval({
                "ZabbixCharts.useEffect.id": ()=>{
                    if (alive) fetchMemOnce();
                }
            }["ZabbixCharts.useEffect.id"], 180_000);
            return ({
                "ZabbixCharts.useEffect": ()=>{
                    alive = false;
                    clearInterval(id);
                }
            })["ZabbixCharts.useEffect"];
        }
    }["ZabbixCharts.useEffect"], [
        host,
        minutes
    ]);
    const fetchTrafOnce = async ()=>{
        setTrafLoading(true);
        try {
            setErr(null);
            const trafUrl = "/api/zbx/metrics/traffic?".concat(host ? "host=".concat(encodeURIComponent(host), "&") : "", "minutes=").concat(minutes);
            const r = await fetch(trafUrl);
            const j = await r.json();
            if (j === null || j === void 0 ? void 0 : j.ok) setTrafData(j.traf);
            else setErr(j.error || "Erro ao obter trafego");
        } catch (e) {
            setErr(String(e));
        } finally{
            setTrafLoading(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ZabbixCharts.useEffect": ()=>{
            let alive = true;
            fetchTrafOnce();
            const id = setInterval({
                "ZabbixCharts.useEffect.id": ()=>{
                    if (alive) fetchTrafOnce();
                }
            }["ZabbixCharts.useEffect.id"], 60_000);
            return ({
                "ZabbixCharts.useEffect": ()=>{
                    alive = false;
                    clearInterval(id);
                }
            })["ZabbixCharts.useEffect"];
        }
    }["ZabbixCharts.useEffect"], [
        host,
        minutes
    ]);
    const memChart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ZabbixCharts.useMemo[memChart]": ()=>{
            var _this, _memData_item;
            if (!memData || ((_this = memData) === null || _this === void 0 ? void 0 : _this.error)) return null;
            const labels = memData.labels;
            const values = memData.values.map({
                "ZabbixCharts.useMemo[memChart].values": (v)=>Number.isFinite(v) ? v : NaN
            }["ZabbixCharts.useMemo[memChart].values"]);
            if (!labels || !values) return null;
            const max = values.reduce({
                "ZabbixCharts.useMemo[memChart].max": (a, b)=>Math.max(a, Math.abs(b || 0))
            }["ZabbixCharts.useMemo[memChart].max"], 0);
            const isBytes = max > 1000; // heuristic: if values large, treat as bytes
            const data = isBytes ? values.map({
                "ZabbixCharts.useMemo[memChart]": (v)=>v / 1_000_000
            }["ZabbixCharts.useMemo[memChart]"]) : values;
            const labelName = ((_memData_item = memData.item) === null || _memData_item === void 0 ? void 0 : _memData_item.name) || "Memory";
            const unit = isBytes ? "MB" : "%";
            return {
                labels,
                datasets: [
                    {
                        label: "".concat(labelName, " (").concat(unit, ")"),
                        data,
                        borderColor: "rgb(255, 159, 64)",
                        backgroundColor: "rgba(255, 159, 64, 0.5)",
                        tension: 0.3
                    }
                ]
            };
        }
    }["ZabbixCharts.useMemo[memChart]"], [
        memData
    ]);
    const trafChart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ZabbixCharts.useMemo[trafChart]": ()=>{
            var _this, _trafData_iface_inItem, _trafData_iface, _trafData_iface_outItem, _trafData_iface1;
            if (!trafData || ((_this = trafData) === null || _this === void 0 ? void 0 : _this.error)) return null;
            const labels = trafData.labels;
            const inValues = trafData.inValues.map({
                "ZabbixCharts.useMemo[trafChart].inValues": (v)=>v / 1_000_000
            }["ZabbixCharts.useMemo[trafChart].inValues"]); // Mb/s
            const outValues = trafData.outValues.map({
                "ZabbixCharts.useMemo[trafChart].outValues": (v)=>v == null ? null : v / 1_000_000
            }["ZabbixCharts.useMemo[trafChart].outValues"]);
            return {
                labels,
                datasets: [
                    {
                        label: (((_trafData_iface = trafData.iface) === null || _trafData_iface === void 0 ? void 0 : (_trafData_iface_inItem = _trafData_iface.inItem) === null || _trafData_iface_inItem === void 0 ? void 0 : _trafData_iface_inItem.name) || "Inbound") + " (Mb/s)",
                        data: inValues,
                        borderColor: "rgb(53, 162, 235)",
                        backgroundColor: "rgba(53, 162, 235, 0.5)",
                        tension: 0.3
                    },
                    {
                        label: (((_trafData_iface1 = trafData.iface) === null || _trafData_iface1 === void 0 ? void 0 : (_trafData_iface_outItem = _trafData_iface1.outItem) === null || _trafData_iface_outItem === void 0 ? void 0 : _trafData_iface_outItem.name) || "Outbound") + " (Mb/s)",
                        data: outValues,
                        borderColor: "rgb(75, 192, 192)",
                        backgroundColor: "rgba(75, 192, 192, 0.5)",
                        tension: 0.3
                    }
                ]
            };
        }
    }["ZabbixCharts.useMemo[trafChart]"], [
        trafData
    ]);
    const chartOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ZabbixCharts.useMemo[chartOptions]": ()=>({
                responsive: true,
                plugins: {
                    legend: {
                        display: true
                    },
                    tooltip: {
                        callbacks: {
                            label: ({
                                "ZabbixCharts.useMemo[chartOptions]": (ctx)=>{
                                    const label = ctx.dataset.label || "";
                                    const v = ctx.parsed.y;
                                    return "".concat(label, ": ").concat(typeof v === "number" ? v.toFixed(2) : v);
                                }
                            })["ZabbixCharts.useMemo[chartOptions]"]
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: ({
                                "ZabbixCharts.useMemo[chartOptions]": (value)=>{
                                    // assume traffic charts dominate; temperature values typically small, no unit needed here
                                    return "".concat(value);
                                }
                            })["ZabbixCharts.useMemo[chartOptions]"]
                        }
                    }
                },
                interaction: {
                    mode: "index",
                    intersect: false
                }
            })
    }["ZabbixCharts.useMemo[chartOptions]"], []);
    if (err) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-red-500",
        children: [
            "Erro: ",
            err
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
        lineNumber: 167,
        columnNumber: 19
    }, this);
    const showTemp = mode === "both" || mode === "temp";
    const showTraffic = mode === "both" || mode === "traffic";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-1 ".concat(mode === "both" ? "md:grid-cols-2" : "", " gap-8"),
        children: [
            showTemp && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "MEMÓRIA"
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                    lineNumber: 176,
                    columnNumber: 18
                }, void 0),
                actions: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>{
                        fetchMemOnce();
                    },
                    className: "bg-gray-200 text-sm px-3 py-1 rounded",
                    children: memLoading ? 'Recarregando…' : 'Recarregar'
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                    lineNumber: 178,
                    columnNumber: 13
                }, void 0),
                children: memChart ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"], {
                    options: chartOptions,
                    data: memChart
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                    lineNumber: 184,
                    columnNumber: 13
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-black",
                    children: "Nenhum dado de memória encontrado."
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                    lineNumber: 186,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                lineNumber: 175,
                columnNumber: 9
            }, this),
            showTraffic && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "TRÁFEGO"
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                    lineNumber: 192,
                    columnNumber: 18
                }, void 0),
                actions: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>{
                        fetchTrafOnce();
                    },
                    className: "bg-gray-200 text-sm px-3 py-1 rounded",
                    children: trafLoading ? 'Recarregando…' : 'Recarregar'
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                    lineNumber: 194,
                    columnNumber: 13
                }, void 0),
                children: trafChart ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"], {
                    options: chartOptions,
                    data: trafChart
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                    lineNumber: 200,
                    columnNumber: 13
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-black",
                    children: "Nenhum dado de tráfego encontrado."
                }, void 0, false, {
                    fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                    lineNumber: 202,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
                lineNumber: 191,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/ZabbixCharts.tsx",
        lineNumber: 173,
        columnNumber: 5
    }, this);
}
_s(ZabbixCharts, "zo5+wO2PyQqilMAHd68rzjesprA=");
_c = ZabbixCharts;
var _c;
__turbopack_context__.k.register(_c, "ZabbixCharts");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/dashboard/ZabbixCharts.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/dashboard/ZabbixCharts.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=src_app_dashboard_68fd4542._.js.map