(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_dashboard_ZabbixCharts_tsx_99b6eeec._.js",
  "static/chunks/_c02fddcb._.js"
],
    source: "dynamic"
});
