(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/dashboard/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function Card(param) {
    let { title, actions, children } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white p-4 rounded-lg shadow-sm w-full",
        children: [
            (title || actions) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    title ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-semibold text-black",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/components/Card.tsx",
                        lineNumber: 9,
                        columnNumber: 20
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {}, void 0, false, {
                        fileName: "[project]/src/app/dashboard/components/Card.tsx",
                        lineNumber: 9,
                        columnNumber: 84
                    }, this),
                    actions ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: actions
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/components/Card.tsx",
                        lineNumber: 10,
                        columnNumber: 22
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/components/Card.tsx",
                lineNumber: 8,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/components/Card.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/components/Card.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/dashboard/TempsMultiChart.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TempsMultiChart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/dashboard/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-chartjs-2/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/chart.js/dist/chart.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Chart"].register(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CategoryScale"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LinearScale"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PointElement"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LineElement"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Title"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Tooltip"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Legend"]);
const COLORS = [
    "#e6194b",
    "#3cb44b",
    "#ffe119",
    "#0082c8",
    "#f58231",
    "#911eb4",
    "#46f0f0",
    "#f032e6",
    "#d2f53c",
    "#fabebe",
    "#008080",
    "#e6beff",
    "#aa6e28",
    "#fffac8",
    "#800000",
    "#aaffc3",
    "#808000",
    "#ffd8b1",
    "#000080",
    "#808080"
];
function TempsMultiChart(param) {
    let { minutes = 60, hostFilter } = param;
    _s();
    const [hosts, setHosts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [hostsLoading, setHostsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [series, setSeries] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [err, setErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Load Zabbix hosts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TempsMultiChart.useEffect": ()=>{
            let alive = true;
            setHostsLoading(true);
            fetch("/api/zbx/hosts").then({
                "TempsMultiChart.useEffect": (r)=>r.json()
            }["TempsMultiChart.useEffect"]).then({
                "TempsMultiChart.useEffect": (j)=>{
                    if (!alive) return;
                    if ((j === null || j === void 0 ? void 0 : j.ok) && Array.isArray(j.hosts)) {
                        const list = j.hosts.map({
                            "TempsMultiChart.useEffect.list": (h)=>({
                                    hostid: h.hostid,
                                    host: h.host,
                                    name: h.name
                                })
                        }["TempsMultiChart.useEffect.list"]);
                        const filtered = typeof hostFilter === "function" ? list.filter(hostFilter) : list;
                        setHosts(filtered);
                    } else {
                        setErr((j === null || j === void 0 ? void 0 : j.error) || "Nenhum host Zabbix encontrado");
                    }
                }
            }["TempsMultiChart.useEffect"]).catch({
                "TempsMultiChart.useEffect": (e)=>{
                    if (alive) setErr(String(e));
                }
            }["TempsMultiChart.useEffect"]).finally({
                "TempsMultiChart.useEffect": ()=>{
                    if (alive) setHostsLoading(false);
                }
            }["TempsMultiChart.useEffect"]);
            return ({
                "TempsMultiChart.useEffect": ()=>{
                    alive = false;
                }
            })["TempsMultiChart.useEffect"];
        }
    }["TempsMultiChart.useEffect"], [
        hostFilter
    ]);
    // Fetch traffic series per host (aggregate in+out to single series per host, values in Mb/s)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TempsMultiChart.useEffect": ()=>{
            let alive = true;
            const fetchAll = {
                "TempsMultiChart.useEffect.fetchAll": async ()=>{
                    try {
                        const results = await Promise.all(hosts.map({
                            "TempsMultiChart.useEffect.fetchAll": async (h)=>{
                                const r = await fetch("/api/zbx/metrics/traffic?host=".concat(encodeURIComponent(h.host), "&minutes=").concat(minutes));
                                const j = await r.json();
                                if (!(j === null || j === void 0 ? void 0 : j.ok) || !(j === null || j === void 0 ? void 0 : j.traf) || !Array.isArray(j.traf.labels)) return {
                                    h,
                                    s: null
                                };
                                const labels = j.traf.labels;
                                const inVals = Array.isArray(j.traf.inValues) ? j.traf.inValues.map({
                                    "TempsMultiChart.useEffect.fetchAll": (x)=>x == null ? null : Number(x)
                                }["TempsMultiChart.useEffect.fetchAll"]) : [];
                                const outVals = Array.isArray(j.traf.outValues) ? j.traf.outValues.map({
                                    "TempsMultiChart.useEffect.fetchAll": (x)=>x == null ? null : Number(x)
                                }["TempsMultiChart.useEffect.fetchAll"]) : [];
                                const map = new Map();
                                for(let i = 0; i < labels.length; i++){
                                    const inV = Number.isFinite(inVals[i]) ? inVals[i] : null;
                                    const outV = outVals[i] != null && Number.isFinite(outVals[i]) ? outVals[i] : null;
                                    const sum = (inV !== null && inV !== void 0 ? inV : 0) + (outV !== null && outV !== void 0 ? outV : 0);
                                    // convert to Mb/s (assuming values are bps)
                                    const mb = isFinite(sum) ? sum / 1_000_000 : null;
                                    if (mb != null) map.set(labels[i], mb);
                                }
                                return {
                                    h,
                                    s: {
                                        labels,
                                        valueByLabel: map
                                    }
                                };
                            }
                        }["TempsMultiChart.useEffect.fetchAll"]));
                        if (!alive) return;
                        const ok = results.filter({
                            "TempsMultiChart.useEffect.fetchAll.ok": (x)=>x.s != null
                        }["TempsMultiChart.useEffect.fetchAll.ok"]);
                        const byHost = {};
                        ok.forEach({
                            "TempsMultiChart.useEffect.fetchAll": (param)=>{
                                let { h, s } = param;
                                byHost[h.host] = s;
                            }
                        }["TempsMultiChart.useEffect.fetchAll"]);
                        setSeries(byHost);
                    } catch (e) {
                        if (alive) setErr(String(e));
                    }
                }
            }["TempsMultiChart.useEffect.fetchAll"];
            if (hosts.length) fetchAll();
            const id = setInterval(fetchAll, 180_000);
            return ({
                "TempsMultiChart.useEffect": ()=>{
                    alive = false;
                    clearInterval(id);
                }
            })["TempsMultiChart.useEffect"];
        }
    }["TempsMultiChart.useEffect"], [
        hosts,
        minutes
    ]);
    const chart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TempsMultiChart.useMemo[chart]": ()=>{
            const allLabels = new Set();
            Object.values(series).forEach({
                "TempsMultiChart.useMemo[chart]": (s)=>s.labels.forEach({
                        "TempsMultiChart.useMemo[chart]": (l)=>allLabels.add(l)
                    }["TempsMultiChart.useMemo[chart]"])
            }["TempsMultiChart.useMemo[chart]"]);
            const labels = Array.from(allLabels).sort();
            const datasets = hosts.map({
                "TempsMultiChart.useMemo[chart].datasets": (h, idx)=>{
                    const s = series[h.host];
                    if (!s) return null;
                    const values = labels.map({
                        "TempsMultiChart.useMemo[chart].datasets.values": (l)=>{
                            var _s_valueByLabel_get;
                            return (_s_valueByLabel_get = s.valueByLabel.get(l)) !== null && _s_valueByLabel_get !== void 0 ? _s_valueByLabel_get : null;
                        }
                    }["TempsMultiChart.useMemo[chart].datasets.values"]);
                    const color = COLORS[idx % COLORS.length];
                    return {
                        label: h.name || h.host,
                        data: values,
                        borderColor: color,
                        backgroundColor: color + "80",
                        spanGaps: true,
                        tension: 0.3
                    };
                }
            }["TempsMultiChart.useMemo[chart].datasets"]).filter(Boolean);
            return {
                labels,
                datasets
            };
        }
    }["TempsMultiChart.useMemo[chart]"], [
        series,
        hosts
    ]);
    const options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TempsMultiChart.useMemo[options]": ()=>({
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true
                    },
                    tooltip: {
                        callbacks: {
                            label: ({
                                "TempsMultiChart.useMemo[options]": (ctx)=>"".concat(ctx.dataset.label, ": ").concat(typeof ctx.parsed.y === "number" ? ctx.parsed.y.toFixed(2) : ctx.parsed.y, " Mb/s")
                            })["TempsMultiChart.useMemo[options]"]
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false
                    }
                },
                interaction: {
                    mode: "index",
                    intersect: false
                }
            })
    }["TempsMultiChart.useMemo[options]"], []);
    if (err) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-red-500",
        children: [
            "Erro: ",
            err
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
        lineNumber: 206,
        columnNumber: 19
    }, this);
    if (hostsLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: "TRÁFEGO (TODOS HOSTS)"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                lineNumber: 209,
                columnNumber: 20
            }, void 0),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center justify-center p-8 text-black",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "animate-spin h-8 w-8 mb-3 text-gray-600",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                className: "opacity-25",
                                cx: "12",
                                cy: "12",
                                r: "10",
                                stroke: "currentColor",
                                strokeWidth: "4"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                                lineNumber: 217,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                className: "opacity-75",
                                fill: "currentColor",
                                d: "M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                                lineNumber: 225,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                        lineNumber: 211,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: "Carregando hosts Zabbix..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                        lineNumber: 231,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                lineNumber: 210,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
            lineNumber: 209,
            columnNumber: 7
        }, this);
    }
    if (!hosts.length) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: "TRÁFEGO (TODOS HOSTS)"
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                lineNumber: 239,
                columnNumber: 20
            }, void 0),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 text-black",
                children: "Nenhum host Zabbix disponível."
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                lineNumber: 240,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
            lineNumber: 239,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$dashboard$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: "TRÁFEGO (TODOS HOSTS)"
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
            lineNumber: 246,
            columnNumber: 18
        }, void 0),
        children: chart.datasets.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-64",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"], {
                data: chart,
                options: options
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
                lineNumber: 249,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
            lineNumber: 248,
            columnNumber: 9
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-black",
            children: "Nenhum dado de tráfego encontrado."
        }, void 0, false, {
            fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
            lineNumber: 252,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/dashboard/TempsMultiChart.tsx",
        lineNumber: 246,
        columnNumber: 5
    }, this);
}
_s(TempsMultiChart, "ZKvZ+naamHLAIYZvgv34jXomc1o=");
_c = TempsMultiChart;
var _c;
__turbopack_context__.k.register(_c, "TempsMultiChart");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/dashboard/TempsMultiChart.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/dashboard/TempsMultiChart.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=src_app_dashboard_9e8043b5._.js.map