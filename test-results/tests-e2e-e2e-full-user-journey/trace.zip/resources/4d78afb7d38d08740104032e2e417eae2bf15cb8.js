(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/dashboard/ZabbixCharts.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_8e73445d._.js",
  "static/chunks/src_app_dashboard_68fd4542._.js",
  "static/chunks/src_app_dashboard_ZabbixCharts_tsx_8f58d217._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/dashboard/ZabbixCharts.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/app/dashboard/TempsMultiChart.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_8e73445d._.js",
  "static/chunks/src_app_dashboard_9e8043b5._.js",
  "static/chunks/src_app_dashboard_TempsMultiChart_tsx_8f58d217._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/dashboard/TempsMultiChart.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);