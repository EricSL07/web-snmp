(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_8e73445d._.js",
  "static/chunks/src_app_dashboard_68fd4542._.js"
],
    source: "dynamic"
});
